package HotelBookingFrm;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hotelbookingPageFactory.hotelbookingPageFactory;

public class StepDefs 
{
	WebDriver driver;
	hotelbookingPageFactory pagefactoryobj;

@Given("^User is on the booking form$")
public void user_is_on_the_booking_form() throws Throwable
{
	System.setProperty("webdriver.chrome.driver", "C:/Users/athomson/chromedriver.exe");
	 driver= new ChromeDriver();
    driver.get("C:\\Users\\athomson\\Documents\\BDD\\BDD\\hotelBooking\\hotelbooking.html");
    pagefactoryobj= new hotelbookingPageFactory(driver);
}

@When("^He enters all details correctly$")
public void he_enters_all_details_correctly() throws Throwable {
	pagefactoryobj.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefactoryobj.setFormlastname("Thomson");
	pagefactoryobj.setFormemail("abc@gmail.com");
	pagefactoryobj.setFormfone("9234567890");
	pagefactoryobj.setFormaddress("Whitefield,Bangalore");
	pagefactoryobj.setFormcity("Bangalore");
	pagefactoryobj.setFormstate("Karnataka");
	pagefactoryobj.setFormnoofpersons("3");
	pagefactoryobj.setFormcardholdername("Alphy T");
	pagefactoryobj.setFormdebitCardno("13459045872");
	pagefactoryobj.setFormCVV("123");
	pagefactoryobj.setFormexpmonth("Jan");
	pagefactoryobj.setFormexpyear("2020");
	
}

@When("^Clicks on 'Confirm booking'$")
public void clicks_on_Confirm_booking() throws Throwable {
	pagefactoryobj.setConfirmbtn();
}

@Then("^Show success message$")
public void show_success_message() throws Throwable {
    String actualmsg= pagefactoryobj.getsuccessmsg();
    String expectedmsg="Booking Completed!";
    assertEquals(actualmsg, expectedmsg);
    driver.close();
}

@When("^Some details are not entered$")
public void some_details_are_not_entered() throws Throwable {
	pagefactoryobj.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefactoryobj.setFormlastname("");
	pagefactoryobj.setFormemail("abc@gmail.com");
	pagefactoryobj.setFormfone("9234567890");
	pagefactoryobj.setFormaddress("Whitefield,Bangalore");
	pagefactoryobj.setFormcity("Bangalore");
	pagefactoryobj.setFormstate("Karnataka");
	pagefactoryobj.setFormnoofpersons("3");
	pagefactoryobj.setFormcardholdername("Alphy T");
	pagefactoryobj.setFormdebitCardno("13459045872");
	pagefactoryobj.setFormCVV("123");
	pagefactoryobj.setFormexpmonth("Jan");
	pagefactoryobj.setFormexpyear("2020");
}
@When("^user enters incorrect \"([^\"]*)\" format and clicks the button$")
public void user_enters_incorrect_format_and_clicks_the_button(String arg1) throws Throwable
{
    pagefactoryobj.setFormfirstname("Alphy");
	//Thread.sleep(500);
	//driver.close();
	pagefactoryobj.setFormlastname("Samson");
	pagefactoryobj.setFormemail("abc@gmail.com");
	pagefactoryobj.setFormfone(arg1);
	Thread.sleep(1000);
	
	//pagefactoryobj.setPfbutton();
	
	
	pagefactoryobj.setFormaddress("Whitefield,Bangalore");
	pagefactoryobj.setFormcity("Bangalore");
	pagefactoryobj.setFormstate("Karnataka");
	pagefactoryobj.setFormnoofpersons("3");
	pagefactoryobj.setFormcardholdername("Alphy S");
	pagefactoryobj.setFormdebitCardno("13459045872");
	pagefactoryobj.setFormCVV("123");
	pagefactoryobj.setFormexpmonth("Jan");
	pagefactoryobj.setFormexpyear("2020");		
	
	
}

@Then("^Show error message$")
public void show_error_message() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    String actualmsg=driver.switchTo().alert().getText();
     String expectedmsg="Please enter valid Contact no.";
      
    //driver.switchTo().alert().accept();
    driver.close();
    assertEquals(actualmsg,expectedmsg);
}


}
