package com.spring.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dao.BankingDAO;
import com.spring.exception.BankingException;
import com.spring.model.Customer;
import com.spring.model.Transaction;

@Service
@Transactional
public class BankingServiceImpl implements BankingService 
{
	@Autowired
	BankingDAO bankDao;

	@Override
	public boolean addCustomer(Customer c)
	{
		bankDao.addCustomer(c);
		return true;
	}

	@Override
	public List<Customer> fetchAllCustomer() 
	{
		List<Customer> list = bankDao.fetchAll();
		return list;
	}

	@Override
	public double deposit(String username,double amount) 
	{
		double balance = 0;
		Customer cus = bankDao.findByUsername(username);
		if(cus != null)
		{
			balance = cus.getAccount1().getBalance();
			cus.getAccount1().setBalance(balance+amount);
			Transaction tran = new Transaction((int) (Math.random()*9999),balance, cus.getAccount1().getAccountNumber());
			cus.getAccount1().setTransaction(tran);
			System.out.println(tran);
			return  cus.getAccount1().getBalance();
		}
		return 0;
	}

	@Override
	public double withdraw(String username, double amount) 
	{
		double balance = 0;
		Customer cus = bankDao.findByUsername(username);
		if(cus != null)
		{
			balance = cus.getAccount1().getBalance();
			cus.getAccount1().setBalance(balance-amount);
			Transaction tran = new Transaction((int) (Math.random()*9999),balance, cus.getAccount1().getAccountNumber());
			cus.getAccount1().setTransaction(tran);
			System.out.println(tran);
			return  cus.getAccount1().getBalance();
		}
		return 0;
	}

	@Override
	public double showBalance(String username)
	{
		Customer cus = bankDao.findByUsername(username);
		if(cus != null)
		{
			return cus.getAccount1().getBalance();
		}
		return 0;
	}

	@Override
	public List<Transaction> printTransaction(String username) throws BankingException 
	{
		Customer cus = bankDao.findByUsername(username);
		if(cus!=null)
		{List<Transaction> lis=cus.getAccount1().getTransaction();
		System.out.println("SSSSSSSSSSSSSSSSSSSHHHHHHHHHHHHHHH"+lis);
			return lis;
		}
		else
		{
			throw new BankingException("Account not found");
		}

	}

	@Override
	public String fundTransfer(String username, long targetAccNo, double amount) throws BankingException 
	{
		Customer cus = bankDao.findByUsername(username);
		if(cus !=null)
		{
			double bal = cus.getAccount1().getBalance();
			if(bal>=amount)
			{
				List<Customer> list = bankDao.fetchAll();
				Iterator<Customer> it = list.iterator();
				while(it.hasNext())
				{
					Customer cus1 = it.next();
					long accNo = cus1.getAccount1().getAccountNumber();
					double bal1  = cus1.getAccount1().getBalance();
					if(accNo == targetAccNo)
					{
						cus.getAccount1().setBalance(bal-amount);
						cus1.getAccount1().setBalance(bal1+amount);
						Transaction tran = new Transaction((int) (Math.random()*9999),
								bal,accNo);
						Transaction tran1 = new Transaction((int) (Math.random()*9999), bal1, cus.getAccount1().getAccountNumber());
						cus.getAccount1().setTransaction(tran);
						cus1.getAccount1().setTransaction(tran1);
						return cus.getUsername();	
					}
				}
				throw new BankingException("Account not found!");
			}
			else
			{
				throw new BankingException("Insufficient Balance");
			}
		}
		else
		{
			throw new BankingException("Username is not found");
		}




	}

	@Override
	public Customer findByUsername(String username) 
	{
		return bankDao.findByUsername(username);
	}

}
