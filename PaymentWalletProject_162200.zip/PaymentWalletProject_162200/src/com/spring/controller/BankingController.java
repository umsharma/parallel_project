package com.spring.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.exception.BankingException;
import com.spring.model.Account;
import com.spring.model.Customer;
import com.spring.model.Transaction;
import com.spring.service.BankingService;

@Controller
public class BankingController 
{
	String views;
	Customer cus;
	@Autowired
	BankingService service;

	@RequestMapping("/home")
	public String showHome()
	{
		return "home";
	}
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String addCustomer(Model model,HttpServletRequest request)
	{
		String view = "AddCustomer";
		model.addAttribute("customer", new Customer());
		
		 return view;
		
	}
	@RequestMapping(value="/addition",method=RequestMethod.POST)
	public String processRegister(Model model, @Valid @ModelAttribute("customer")Customer customer,BindingResult result)
	{
		String view = "";

		if (result.hasErrors()) {
			view = "AddCustomer";
		} else {
			Account ac = new Account();
			Transaction tran = new Transaction();
			ac.setTransaction(tran);
			customer.setAccount1(ac);
			System.out.println(customer);
			service.addCustomer(customer);
			model.addAttribute("cus", customer);
			view = "AddSuccess";
		}
		return view;		
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String showLogin(Model model)
	{
		String view = "loginPage";
		model.addAttribute("customer", new Customer());
		
		 return view;
		
	}

	@RequestMapping(value="/page",method=RequestMethod.POST)
	public String processLogin(Model model,@ModelAttribute("customer")Customer customer,BindingResult result,HttpServletRequest request)
	{
		ServletContext context = request.getServletContext();
		context.setAttribute("username", customer.getUsername());
			//String view = "loginPage";
			 cus = service.findByUsername(customer.getUsername());
			if(customer.getPassword().equals(cus.getPassword()))
			{
				HttpSession session = request.getSession();
				session.setAttribute("cust", cus);
				 views = "MainLoginPage";	
				 
			
			}
		

				
		return views;
			
	}
	@RequestMapping(value="/deposit",method=RequestMethod.GET)
	public String showDeposit(Model model,HttpServletRequest request)
	{
		String view = "Deposit";
		model.addAttribute("username", cus.getUsername());
		model.addAttribute("accountNumber", cus.getAccount1().getAccountNumber());
		
		 return view;
	}
	@RequestMapping(value="/successDeposit",method=RequestMethod.POST)
	public String processDeposit(Model model,@RequestParam("amount")double amount,@RequestParam("userName")String username)
	{
		views ="showDeposit";
		
			double balance = service.deposit(username,amount);
			model.addAttribute("balance", balance);
			
			
				
			return views;
	}
	@RequestMapping(value="/withdraw",method=RequestMethod.GET)
	public String showWithdraw(Model model,HttpServletRequest request)
	{
		String view = "Withdraw";
		model.addAttribute("username", cus.getUsername());
		model.addAttribute("accountNumber", cus.getAccount1().getAccountNumber());
		
		 return view;
	}
	@RequestMapping(value="/successWithdraw",method=RequestMethod.POST)
	public String processWithdraw(Model model,@RequestParam("amount")double amount,@RequestParam("userName")String username)
	{
		views ="showWithdraw";
		
			double balance = service.withdraw(username, amount);
			model.addAttribute("balance", balance);
			
				
			return views;
	}
	@RequestMapping(value="/showBal",method=RequestMethod.GET)
	public String showbal(Model model,HttpServletRequest request)
	{
		String view = "showbalance";
		model.addAttribute("username", cus.getUsername());
		model.addAttribute("accountNumber", cus.getAccount1().getAccountNumber());
		
		 return view;
	}
	
	
	@RequestMapping(value="/successBalance",method=RequestMethod.POST)
	public String showBalance(Model model,HttpServletRequest request,@RequestParam("userName")String username)
	{
		views ="showbalance";
		//ServletContext context = request.getServletContext();
	//String uName = String.valueOf(context.getAttribute("username"));
	

		 double bal = service.showBalance(username);
		model.addAttribute("balance", bal);
		String view="Balance";
			return view;
	}
	@RequestMapping(value="/fundtransfer",method=RequestMethod.GET)
	public String showTransfer(Model model, HttpServletRequest request)
	{
		String view = "fundTransfer";
		HttpSession session = request.getSession();
		model.addAttribute("customer", session.getAttribute("cust"));
		 return view;
		
	}
	
	@RequestMapping(value="/successTransfer",method=RequestMethod.POST)
	public String processTransfer(Model model,HttpServletRequest request,
			@ModelAttribute("customer")Customer customer,
			@RequestParam("targetAccNo")long targetAccNo,
			@RequestParam("amount")double amount) throws BankingException 	{
		
		String uName;
			uName = service.fundTransfer(customer.getUsername(), targetAccNo, amount);

			model.addAttribute("sourceUName", uName);
		   String  view="showTransfer";
			return view;
	}
	@RequestMapping(value="/printTransaction",method=RequestMethod.GET)
	public String showTransaction(Model model,HttpServletRequest request)
	{
		String view = "showTransaction";
		HttpSession session = request.getSession();
		model.addAttribute("customer", session.getAttribute("cust"));
		 return view;
		
	}
	@RequestMapping(value="/showTrans",method=RequestMethod.POST)
	public String processTransaction(Model model,@ModelAttribute("customer")Customer customer) throws BankingException
	{
		List<Transaction> list = service.printTransaction(customer.getUsername());
		model.addAttribute("listCus", list);
		String view = "showTransaction";
		 return view;
		
	}
	

}
