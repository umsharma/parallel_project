package HotelLogin;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import HotelBookingPageFactory.HotelBookingPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	HotelBookingPageFactory pagefactory;
        WebDriver driver;
	@Given("^Open the browser$")
	public void open_the_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		
		driver=new ChromeDriver();
		
	}

	@When("^open the login\\.html page$")
	public void open_the_login_html_page() throws Throwable {
		driver.get("file:///C:/Users/umsharma/Documents/BDD/login.html");
	}

	@Then("^verify the heading$")
	public void verify_the_heading() throws Throwable {
		 String text= driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		   assertEquals("Hotel Booking Application", text);
			System.out.println(text);
	}

	
	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/umsharma/Documents/BDD/login.html");
	}

	@Given("^User enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable {
	   driver.findElement(By.name("userName")).sendKeys("capgemini");
	   driver.findElement(By.name("userPwd")).sendKeys("capg1234");
	   Thread.sleep(3000);
	}

	@When("^User has the valid username and passowrd$")
	public void user_has_the_valid_username_and_passowrd() throws Throwable {
	   driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}

	@Then("^Application takes to the 'Hotel booking' page$")
	public void application_takes_to_the_Hotel_booking_page() throws Throwable {
	 driver.get("file:///C:/Users/umsharma/Documents/BDD/hotelbooking.html");
	}

	@Given("^User launshes the browser and open the application$")
	public void user_launshes_the_browser_and_open_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		 driver.get("file:///C:/Users/umsharma/Documents/BDD/hotelbooking.html");
		 pagefactory = new HotelBookingPageFactory(driver);
	}

	@Given("^User enter the complete entries$")
	public void user_enter_the_complete_entries() throws Throwable {
	pagefactory.setFormfirstname("Umesh");
		
		pagefactory.setFormlastname("Sharma");
		pagefactory.setFormemail("sharma.umesh209@gmail.com");
		pagefactory.setFormfone("9719950074");
		pagefactory.setFormaddress("WhiteField,Bangalore");
		pagefactory.setFormcity("Bangalore");
		pagefactory.setFormstate("Karnataka");
		pagefactory.setFormnoofpersons("4");
		pagefactory.setFormcardholdername("UMESH SHARMA");
		pagefactory.setFormdebitCardno("6070930014882245");
		pagefactory.setFormCVV("344");
		pagefactory.setFormexpmonth("April");
		pagefactory.setFormexpyear("2022");
		
	Thread.sleep(5000);
		
		
	}

	@When("^Click on the \"([^\"]*)\"$")
	public void click_on_the(String arg1) throws Throwable {
		pagefactory.setConfirmbtn();
	}

	@Then("^show booking confirmed message$")
	public void show_booking_confirmed_message() throws Throwable {
		 String actualmsg= pagefactory.getsuccessmsg();
		    String expectedmsg="Booking Completed!";
		    assertEquals(actualmsg, expectedmsg);
	}


	@Given("^User launches the browser & open the application$")
	public void user_launches_the_browser_open_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		 driver.get("file:///C:/Users/umsharma/Documents/BDD/hotelbooking.html");
		 pagefactory = new HotelBookingPageFactory(driver);
	}

	@Given("^User enter the entires and left first name blank$")
	public void user_enter_the_entires_and_left_first_name_blank() throws Throwable {
	pagefactory.setFormfirstname("Umesh");
		
		pagefactory.setFormlastname("");
		pagefactory.setFormemail("sharma.umesh209@gmail.com");
		pagefactory.setFormfone("9719950074");
		pagefactory.setFormaddress("WhiteField,Bangalore");
		pagefactory.setFormcity("Bangalore");
		pagefactory.setFormstate("Karnataka");
		pagefactory.setFormnoofpersons("4");
		pagefactory.setFormcardholdername("UMESH SHARMA");
		pagefactory.setFormdebitCardno("6070930014882245");
		pagefactory.setFormCVV("344");
		pagefactory.setFormexpmonth("April");
		pagefactory.setFormexpyear("2022");
		
	Thread.sleep(5000);
		
	}

	@When("^Click on the \"([^\"]*)\" button$")
	public void click_on_the_button(String arg1) throws Throwable {
	  
	}

	@Then("^Alert message \"([^\"]*)\"$")
	public void alert_message(String arg1) throws Throwable {
	 
	}


	
	
}
