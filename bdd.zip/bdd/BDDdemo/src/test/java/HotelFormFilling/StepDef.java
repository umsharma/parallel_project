package HotelFormFilling;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hotelbookingpagefactory.hotelbookingpagefactory;

public class StepDef {

	hotelbookingpagefactory pagefactory;
	WebDriver driver;
	@Given("^user is on the hotel booking form$")
	public void user_is_on_the_hotel_booking_form() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file:///C:/Users/umsharma/Documents/BDD/hotelbooking.html");
	 pagefactory= new hotelbookingpagefactory(driver);
	
	}

	@When("^all the entries are filled$")
	public void all_the_entries_are_filled() throws Throwable {
		pagefactory.setFormfirstname("Umesh");
		
		pagefactory.setFormlastname("Sharma");
		pagefactory.setFormemail("sharma.umesh209@gmail.com");
		pagefactory.setFormfone("9719950074");
		pagefactory.setFormaddress("WhiteField,Bangalore");
		pagefactory.setFormcity("Bangalore");
		pagefactory.setFormstate("Karnataka");
		pagefactory.setFormnoofpersons("4");
		pagefactory.setFormcardholdername("UMESH SHARMA");
		pagefactory.setFormdebitCardno("6070930014882245");
		pagefactory.setFormCVV("344");
		pagefactory.setFormexpmonth("April");
		pagefactory.setFormexpyear("2022");
		
	Thread.sleep(5000);
		
		
	}

	@When("^click on 'confirm button'$")
	public void click_on_confirm_button() throws Throwable {
		pagefactory.setConfirmbtn();
		
		
	}

	@Then("^show success message$")
	public void show_success_message() throws Throwable {
	 
		 String actualmsg= pagefactory.getsuccessmsg();
		    String expectedmsg="Booking Completed!";
		    assertEquals(actualmsg, expectedmsg);
		 //   driver.close();
		
	}

	
}
