package HotelBooking;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hotelbookingpagefactory.hotelbookingpagefactory;

public class StepDefs {

	WebDriver driver;
	hotelbookingpagefactory pagefactory;
/*	@Given("^User launches the browser$")
	public void user_launches_the_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
	driver=new ChromeDriver();
	}
	
	@When("^open the login\\.html page$")
	public void open_the_login_html_page() throws Throwable {
		driver.get("file:///C:/Users/umsharma/Documents/BDD/login.html");
	}
	
	@Then("^Verify the heading$")
	public void verify_the_heading() throws Throwable {
		 String text= driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		   assertEquals("Hotel Booking Application", text);
			System.out.println(text);
		}
	
	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		
	driver= new ChromeDriver();
	 driver.get("file:///C:/Users/umsharma/Documents/BDD/login.html");
	}

	@Given("^User has the valid username and passowrd$")
	public void user_has_the_valid_username_and_passowrd() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
	}

	@When("^User enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable {
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		Thread.sleep(5000);
		
	}

	@Then("^Application takes to the 'Hotel booking' page$")
	public void application_takes_to_the_Hotel_booking_page() throws Throwable {
		driver.get("file:///C:/Users/umsharma/Documents/BDD/hotelbooking.html");
	}*/

     
	@Given("^user is on the hotel booking form$")
	public void user_is_on_the_hotel_booking_form() throws Throwable {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("file:///C:/Users/umsharma/Documents/BDD/hotelbooking.html");
	 pagefactory= new hotelbookingpagefactory(driver);
	
	}

	@When("^all the entries are filled$")
	public void all_the_entries_are_filled() throws Throwable {
		pagefactory.setFormfirstname("Umesh");
		//Thread.sleep(500);
		//driver.close();
		pagefactory.setFormlastname("Sharma");
		pagefactory.setFormemail("sharma.umesh209@gmail.com");
		pagefactory.setFormfone("9719950074");
		pagefactory.setFormaddress("WhiteField,Bangalore");
		pagefactory.setFormcity("Bangalore");
		pagefactory.setFormstate("Karnataka");
		pagefactory.setFormnoofpersons("2");
		pagefactory.setFormcardholdername("UMESH SHARMA");
		pagefactory.setFormdebitCardno("6070930014882245");
		pagefactory.setFormCVV("344");
		pagefactory.setFormexpmonth("April");
		pagefactory.setFormexpyear("2022");
		
	Thread.sleep(5000);
		
		
	}

	@When("^click on 'confirm button'$")
	public void click_on_confirm_button() throws Throwable {
		pagefactory.setConfirmbtn();
		
		
	}

	@Then("^show success message$")
	public void show_success_message() throws Throwable {
	 
		 String actualmsg= pagefactory.getsuccessmsg();
		    String expectedmsg="Booking Completed!";
		    assertEquals(actualmsg, expectedmsg);
		 //   driver.close();
		
	}

	
	}

