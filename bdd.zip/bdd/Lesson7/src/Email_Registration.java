import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Email_Registration {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/umsharma/Downloads/WorkingWithForms.html");
/*	String parentWindow = driver.getWindowHandle().toString();
		Thread.sleep(5000);
		*/
		//driver.manage().window().maximize();
		Thread.sleep(3000);
		//driver.findElement(By.partialLinkText("https://www.opencart.com/index.php?route=account/register")).click();;
		WebElement searchBox = driver.findElement(By.id("txtUserName"));
		searchBox.sendKeys("sharma209umesh");
		WebElement searchBox1 = driver.findElement(By.id("txtPassword"));
		searchBox1.sendKeys("Manju@209");
		WebElement searchBox2 = driver.findElement(By.id("txtConfPassword"));
		searchBox2.sendKeys("Manju@209");
		WebElement searchBox3 = driver.findElement(By.id("txtFirstName"));
		searchBox3.sendKeys("Umesh");
		WebElement searchBox4 = driver.findElement(By.id("txtLastName"));
		searchBox4.sendKeys("Sharma");
		driver.findElement(By.id("rbMale")).click();
		WebElement searchBox6 = driver.findElement(By.id("DOB"));
		searchBox6.sendKeys("01-08-1995");
		WebElement searchBox7 = driver.findElement(By.id("txtEmail"));
		searchBox7.sendKeys("sharma.umesh209@gmail.com");
		WebElement searchBox8 = driver.findElement(By.id("txtAddress"));
		searchBox8.sendKeys("Aligarh");
		WebElement searchBox9 = driver.findElement(By.name("City"));
		searchBox9.sendKeys("Mumbai");
		WebElement searchBox10 = driver.findElement(By.id("txtPhone"));
		searchBox10.sendKeys("9719950074");
		driver.findElement(By.name("chkHobbies")).click();
		
		driver.findElement(By.name("submit")).click();
		
        //driver.findElement(By.id("alert")).click();
		
		Thread.sleep(5000);
		
		Alert alert=driver.switchTo().alert();
		System.out.println("The alert message is : " + alert.getText());
		alert.accept();
		
		Thread.sleep(5000);
		
		driver.switchTo().window("PopupWindow");
		Thread.sleep(5000);
		
		
		
		
	
	}

	
}
