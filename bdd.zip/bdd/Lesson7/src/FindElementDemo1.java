import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindElementDemo1 {

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.opencart.com");
	//	driver.manage().window().maximize();
		
		Thread.sleep(3000);
		
	//	WebElement searchBox = driver.findElement(By.name("search"));
		
	//	searchBox.sendKeys("Phone");
//		driver.findElement(By.xpath("//*[@id=\"search\"]/span/button")).click();
		driver.findElement(By.cssSelector("#navbar-collapse-header > div > a.btn.btn-black.navbar-btn")).click();	
		WebElement searchBox = driver.findElement(By.name("username"));
		searchBox.sendKeys("sharma209umesh");
		WebElement searchBox1 = driver.findElement(By.name("firstname"));
		searchBox1.sendKeys("umesh");
		WebElement searchBox2 = driver.findElement(By.name("lastname"));
		searchBox2.sendKeys("sharma");
		WebElement searchBox3 = driver.findElement(By.name("email"));
		searchBox3.sendKeys("sharma.umesh209@gmail.com");
		WebElement searchBox4 = driver.findElement(By.id("input-country"));
		searchBox4.sendKeys("India");
		WebElement searchBox5 = driver.findElement(By.name("password"));
		searchBox5.sendKeys("Manju@209");
		
		Thread.sleep(3000);
		
	//	driver.findElement(By.linkText("Login")).click();
	
	//driver.quit();
	}
	
	
}
