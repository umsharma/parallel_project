import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demo {
	
	public static void main(String[] args) throws InterruptedException{

	{
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	   	          boolean title = driver.getTitle().contains("Google");
	   	          if(title) {
		   	String currentURL = driver.getCurrentUrl();
		
			boolean b = driver.getPageSource().contains("your text");
	        		System.out.println("Expected title is present ");
	        		}
	                  else if(!title) {
	       	System.out.println(" Expected title is not present"); 
		}

	
}
}}