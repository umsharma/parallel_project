package EmailRegistration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import loginfactory.LoginPageFactory;

public class verifyEmailRegistrationFactory {
	static String driverPath = "C:\\Users\\umsharma\\Desktop\\New folder\\BDD Jar Files\\Seleniums Lib";
	@Test
	public void veryfylogin()
	{
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		;
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/umsharma/Downloads/WorkingWithForms.html");
		driver.manage().window().maximize();
	// creating object of LoginPage class
		
		EmailRegistrationFactory login1 = new EmailRegistrationFactory(driver);
		login1.register_misapp("sharma209umesh","manju@209","manju@209","umesh","sharma","Male","01-08-1995","sharma.umesh209@gmail.com","aligarh"
				,"9719950074","Music");
	//	login.typeusername();
		//login.typeconfirmpwd();
		
		
	}

	
	
}
