package EmailRegistration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EmailRegistrationFactory {
	

	WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public EmailRegistrationFactory(WebDriver driver)
	{
		this.driver =driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
       
	}
	//using ID
	@FindBy(id="txtUserName")
	@CacheLookup // to store the element in cache memory
	WebElement username;
	
	
	@FindBy(id="txtPassword")
	@CacheLookup // to store the element in cache memory
	WebElement password;
	
	
	//using Xpath
		@FindBy(how=How.XPATH, using="//*[@id='txtConfPassword']")
		@CacheLookup
		WebElement confrmpass;
		
		//using cssSelector
		@FindBy(how=How.CSS, using="#txtFirstName")
		@CacheLookup // to store the element in cache memory
		WebElement firstname;
		
		@FindBy(how=How.CSS, using="#txtLastName")
		@CacheLookup // to store the element in cache memory
		WebElement lastname;
		
		//using name
		@FindBy(how=How.CSS,using="#rbMale")
		@CacheLookup // to store the element in cache memory
		List<WebElement> Gender;
		
		@FindBy(how=How.XPATH,using="//*[@id=\"DOB\"]")
		@CacheLookup // to store the element in cache memory
		WebElement DOB;
		
		@FindBy(how=How.ID,using="txtEmail")
		@CacheLookup // to store the element in cache memory
		WebElement Email;
		

		@FindBy(how=How.NAME,using="Address")
		@CacheLookup // to store the element in cache memory
		WebElement Address;
		
		@FindBy(how=How.NAME,using="City")
		@CacheLookup // to store the element in cache memory
		WebElement city;
		
		@FindBy(how=How.ID,using="txtPhone")
		@CacheLookup // to store the element in cache memory
		WebElement Phone;
		
		@FindBy(how=How.NAME,using="chkHobbies")
		@CacheLookup // to store the element in cache memory
		List<WebElement> hobbies;
		
		@FindBy(how=How.NAME,using="submit")
		@CacheLookup // to store the element in cache memory
		WebElement Submit;
		
		
		public void register_misapp(String un, String pass, String cpass,
				String fname, String lname, String gender,String dob, String email,
				String address,String phone,String hobbie)
		{
			username.sendKeys(un);
			password.sendKeys(pass);
			confrmpass.sendKeys(cpass);
			firstname.sendKeys(fname);
			lastname.sendKeys(lname);
			 for(WebElement webElement : Gender)
			    {
			        String radioSelection;
			        radioSelection=webElement.getAttribute("value").toString();
			        if(radioSelection.equals(gender))
			        {
			            webElement.click();
			        }
			    }
		    DOB.sendKeys(dob);
		    Email.sendKeys(email);
		    Address.sendKeys(address); 
		    Select drpCity = new Select(driver.findElement(By.name("City")));
	        drpCity.selectByIndex(2);
		    Phone.sendKeys(phone);
		    for(WebElement webElement : hobbies)
		    {
		        String radioSelection;
		        radioSelection=webElement.getAttribute("value").toString();
		        if(radioSelection.equals(hobbie))
		        {
		            webElement.click();
		        }
		    }
		  
		   
		   
		   
		}
		
		
		
		
		

}
