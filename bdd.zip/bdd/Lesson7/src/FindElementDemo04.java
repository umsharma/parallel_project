import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FindElementDemo04 
{

	public static void main(String[] args) throws InterruptedException
	{
		WebElement element;		

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/umsharma/Downloads/WorkingWithForms.html");
          String parentWindow = driver.getWindowHandle().toString();
		
		
		driver.manage().window().maximize();
		
		Thread.sleep(3000);
		
		element = driver.findElement(By.id("txtUserName"));
        element.sendKeys("sharma209umesh");
                
        driver.findElement(By.name("txtPwd")).sendKeys("Manju@209");
                
        driver.findElement(By.className("Format")).sendKeys("Manju@209");
                
        driver.findElement(By.cssSelector("Input.Format1")).sendKeys("Umesh");
                
        driver.findElement(By.cssSelector("Input#txtLastName")).sendKeys("Sharma");
              
        List<WebElement> radioElem = driver.findElements(By.name("gender"));
        
        for(WebElement webElement : radioElem)
        {
        		String radioSelection;
        		radioSelection = webElement.getAttribute("value").toString();
        		if(radioSelection.equals("Male"))
        		{
        			webElement.click();
        		}
        		        	    			
        		try
        		{
        			Thread.sleep(500);
        		}
        		catch(InterruptedException ex)
        		{
        			System.out.println(ex.getMessage());
        		}	
        }
        
        driver.findElement(By.cssSelector("input[type=date")).sendKeys("01/08/1995");
        
        driver.findElement(By.cssSelector("input.Format[name='Email'")).sendKeys("sharma.umesh209@gmail.com");
        
        driver.findElement(By.name("Address")).sendKeys("Aligarh");
        
        Select drpCity = new Select(driver.findElement(By.name("City")));
        drpCity.selectByIndex(2);
       //drpCity.selectByValue("Pune1");
      //  drpCity.selectByVisibleText("Mumbai1");
        
    	driver.findElement(By.name("Phone")).sendKeys("7055845423");
        
        List<WebElement> checkElem = driver.findElements(By.name("chkHobbies"));
        
        for(WebElement webElement : checkElem)
        {
        		String checkSelection;
        		checkSelection = webElement.getAttribute("value").toString();
        		if(checkSelection.equals("Music"))
        		{
        			webElement.click();
        		}
        		if(checkSelection.equals("Movies"))
        		{
        			webElement.click();
        		}
        		        	    			
        		try
        		{
        			Thread.sleep(500);
        		}
        		catch(InterruptedException ex)
        		{
        			System.out.println(ex.getMessage());
        		}	
        }
        
    	
		driver.findElement(By.name("submit")).click();
        Thread.sleep(5000);
	
		Alert alert=driver.switchTo().alert();
		System.out.println("The alert message is : " + alert.getText());
		alert.accept();
		
		Thread.sleep(5000);
		
		/*driver.switchTo().window("PopupWindow");
		Thread.sleep(5000);
		driver.close();*/
		
    
    }
     
	}