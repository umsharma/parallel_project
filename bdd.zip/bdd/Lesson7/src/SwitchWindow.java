import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchWindow {
	
	public static void main(String[] args) throws InterruptedException
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\umsharma\\chromedriver\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/umsharma/Downloads/BDD_Switch_Window_Example/PopupWin.html");
		String parentWindow = driver.getWindowHandle().toString();
		Thread.sleep(5000);
		
		driver.findElement(By.name("Open")).click();
		//Thread.sleep(5000);
		
		driver.switchTo().window("PopupWindow");
		Thread.sleep(5000);
		//driver.close();
		
		driver.switchTo().window(parentWindow);
		Thread.sleep(5000);
		//driver.close();

	}



}
