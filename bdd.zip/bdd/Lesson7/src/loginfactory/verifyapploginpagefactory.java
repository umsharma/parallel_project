package loginfactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import loginfactory.LoginPageFactory;

public class verifyapploginpagefactory {
	static String driverPath = "C:\\\\Users\\\\umsharma\\\\Desktop\\\\New folder\\\\BDD Jar Files\\\\Seleniums Lib";
	@Test
	public void veryfylogin()
	{
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("file:///C:/Users/umsharma/Downloads/WorkingWithForms.html");
		driver.manage().window().maximize();
	// creating object of LoginPage class
		
		LoginPageFactory login1 = new LoginPageFactory(driver);
		login1.login_misapp("alphy","alphy","alphy");
	//	login.typeusername();
		//login.typeconfirmpwd();
		
		
	}

}