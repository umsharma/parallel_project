package com.ohadr.security.oauth.examples;


/**
 * @author Ryan Heaton
 */
public interface DemoService
{


	String getTrustedMessage();

}
