package BookHotelLogin;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"}) // for ignoring any this scenario put ~ before @

public class RunTestCukes {

}
