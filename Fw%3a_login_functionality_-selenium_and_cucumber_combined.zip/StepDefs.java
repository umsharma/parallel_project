package BookHotelLogin;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs 
{
	WebDriver driver;
	private String userName;
	private String passWord;
	@Given("^User launches the browser$")
	public void user_launches_the_browser() throws Throwable
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/athomson/chromedriver.exe");
		 driver= new ChromeDriver();

	}

	@When("^User enters the HotelBooking URL$")
	public void user_enters_the_HotelBooking_URL() throws Throwable 
	{
		driver.get("C:\\Users\\athomson\\Documents\\BDD\\BDD\\hotelBooking\\login.html");
	}

	@Then("^Verify login page heading$")
	public void verify_login_page_heading_as_Hotel_Booking_Application() throws Throwable {
	    String text= driver.findElement(By.xpath("//*[@id='mainCnt']/div/div[1]/h1")).getText();
	  //  String pageheading=to_string(text);
	    assertEquals("Hotel Booking Application", text);
	    driver.close();
	}

	@Given("^User launches the browser and opens the application$")
	public void user_launches_the_browser_and_opens_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:/Users/athomson/chromedriver.exe");
		 driver= new ChromeDriver();
		 driver.get("C:\\Users\\athomson\\Documents\\BDD\\BDD\\hotelBooking\\login.html");

	}

	@Given("^User has the valid username and passowrd$")
	public void user_has_the_valid_username_and_passowrd() throws Throwable 
	{
		userName="capgemini";
		passWord="capg1234";
		

	}

	/*@When("^User enters the valid username and valid password$")
	public void user_enters_the_valid_username_and_valid_password() throws Throwable
	{

		driver.findElement(By.name("userName")).sendKeys(userName);
		driver.findElement(By.name("userPwd")).sendKeys(passWord);
		driver.findElement(By.className("btn")).click();
	}*/
	
	@When("^User enters the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_the_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("userName")).sendKeys(arg1);
		driver.findElement(By.name("userPwd")).sendKeys(arg2);
		driver.findElement(By.className("btn")).click();
	}
	@Then("^Application takes to the 'Hotel booking' page$")
	public void application_takes_to_the_Hotel_booking_page() throws Throwable {

		String title=driver.getTitle();
		System.out.println(title);
		assertEquals(title, "Hotel Booking");
		driver.close();
		
	}

	@When("^User enters the invalid username or invalid password$")
	public void user_enters_the_invalid_username_or_invalid_password() throws Throwable
	{
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		//driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		driver.findElement(By.className("btn")).click();
		

	}

	@Then("^show error message$")
	public void show_error_message() throws Throwable {
	   String errmsg= driver.findElement(By.id("pwdErrMsg")).getText();
	   String experrmsg="* Please enter password.";
	   assertEquals(errmsg,experrmsg);
	   driver.close();
	}


}
