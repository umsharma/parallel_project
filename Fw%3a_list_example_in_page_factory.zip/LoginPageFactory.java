package package1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {
	
	WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public LoginPageFactory(WebDriver driver)
	{
		this.driver =driver;
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
       
	}
		
	@FindBy(id="txtUserName")
	@CacheLookup // to store the element in cache memory
	WebElement username;
	
	//using How class	
	@FindBy(how=How.ID, using="txtPassword")
	@CacheLookup
	WebElement password;
	
	//using Xpath
	@FindBy(how=How.XPATH, using="//*[@id='txtConfPassword']")
	@CacheLookup
	WebElement confrmpass;
	
	@FindBy(how=How.NAME, using="chkHobbies")
	@CacheLookup
	WebElement hobbie1;


	@FindBy(how=How.NAME, using="chkHobbies") 
	List<WebElement> hobbies;
	
	public void login_misapp(String un, String pass, String cpass)
	{
		username.sendKeys(un);
		password.sendKeys(pass);
		confrmpass.sendKeys(cpass);
	}
	
	public void select_hobby(String h1,String h2)
	{
		
      
        for(WebElement webElement : hobbies)
        {
        		String checkSelection;
        		checkSelection = webElement.getAttribute("value").toString();
        		if(checkSelection.equals(h1))
        		{
        			webElement.click();
        		}
        		if(checkSelection.equals(h2))
        		{
        			webElement.click();
        			
        		}
        		        	    			
        		
        }
 
	}
	
}
