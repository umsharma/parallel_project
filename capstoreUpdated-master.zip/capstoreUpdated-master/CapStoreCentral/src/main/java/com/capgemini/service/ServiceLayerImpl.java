package com.capgemini.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.DAOLayerAdmin;
import com.capgemini.dao.DAOLayerCustomer;
import com.capgemini.dao.DAOLayerMerchant;
import com.capgemini.dto.Admin;
import com.capgemini.dto.Customers;
import com.capgemini.dto.Products;
import com.capgemini.exception.CapStoreException;

@Service
public class ServiceLayerImpl implements ServiceLayer
{
	@Autowired
	private DAOLayerAdmin daorefAdmin;
	@Autowired
	private DAOLayerCustomer daorefCustomer;
	@Autowired
	private DAOLayerMerchant daorefMerchant;

	@Override
	public Admin validateAdmin(Admin admin)
	{
		return daorefAdmin.validateAdmin(admin);
	}

	
	@Override
	public Admin findById(int id) {
		return daorefAdmin.findById(id);
	}


	@Override
	public Customers createAccount(Customers cusDTO) {
		
		List<Customers> listOfCustomers=daorefCustomer.getAllCustomer();
		
		for (Customers c:listOfCustomers) {
			if(cusDTO.getCustomerEmail().equals(c.getCustomerEmail()))
			{
				Customers cnew = new Customers();
				cnew.setCustomerName("Dummy");
				return cnew;
				
			}
				
			else if(cusDTO.getCustomerMobile().equals(c.getCustomerMobile()))
			{
				Customers cnew2 = new Customers();
				cnew2.setCustomerName("Dummy");
				return cnew2;
				
			}
		}
		 return daorefCustomer.createAccount(cusDTO);
		
	}


	@Override
	public Customers validateCustomerForLogin(Customers customer) {
		return daorefCustomer.validateCustomerForLogin(customer);
	}


	@Override
	public String check() {
		return daorefCustomer.check();
	}


	@Override
	public List<Products> findAll() {
		
		return daorefCustomer.findAll();
	}
}