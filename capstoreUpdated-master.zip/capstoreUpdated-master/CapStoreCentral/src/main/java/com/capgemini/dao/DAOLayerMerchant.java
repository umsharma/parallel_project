package com.capgemini.dao;

import com.capgemini.dto.Products;

public interface DAOLayerMerchant {
	
	public boolean addProduct(Products product);

}
