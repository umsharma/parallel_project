package com.capgemini.service;

import java.util.List;

import com.capgemini.dto.Admin;
import com.capgemini.dto.Customers;
import com.capgemini.dto.Products;
import com.capgemini.exception.CapStoreException;

public interface ServiceLayer
{
	public Admin validateAdmin(Admin admin);
	public Admin findById(int id);
	public Customers createAccount(Customers cusDTO) ;
	public Customers validateCustomerForLogin(Customers customer);
	public String check();
	public List<Products> findAll();
}