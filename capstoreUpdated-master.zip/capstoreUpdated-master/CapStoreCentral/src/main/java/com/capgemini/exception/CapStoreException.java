package com.capgemini.exception;

public class CapStoreException extends Exception {

	public CapStoreException(String string) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
