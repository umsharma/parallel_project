package com.capgemini.dto;

import java.util.ArrayList;
import java.util.List;

public class ProductListDummy {
	
	    private List<Products> products;
	    
	 
	    public ProductListDummy() {
	        products = new ArrayList<>();
	    }

		public List<Products> getProducts() {
			return products;
		}

		public void setProducts(List<Products> products) {
			this.products = products;
		}
		public List<Products> getSpecificProducts(ProductCategory pc)
		{
			List<Products> specificProducts=new ArrayList<>();
			List<Products> l=this.getProducts();
			
			for(Products p:l)
			{
				
				if(p.getProductCategory().toString().equals(pc.toString())){
					/*System.out.println("***"+pc);
					System.out.println(p.toString());
					*/
					System.out.println(p.getProductCategory().toString());
					specificProducts.add(p);}
				else continue;
			}
			System.out.println(specificProducts.toString());
			return specificProducts;
		}
	 
	    
	}


