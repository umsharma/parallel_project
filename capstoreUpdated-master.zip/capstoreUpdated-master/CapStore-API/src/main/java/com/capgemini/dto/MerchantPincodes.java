package com.capgemini.dto;

public class MerchantPincodes {
	private int pincodeId;

	public int getPincodeId() {
		return pincodeId;
	}

	public void setPincodeId(int pincodeId) {
		this.pincodeId = pincodeId;
	}
	
	
}
