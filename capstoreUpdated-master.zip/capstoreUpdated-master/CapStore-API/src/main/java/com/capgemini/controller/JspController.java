package com.capgemini.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.dto.Admin;
import com.capgemini.dto.Customers;
import com.capgemini.dto.ProductCategory;
import com.capgemini.dto.ProductListDummy;
import com.capgemini.dto.Products;

@Controller
public class JspController {

	@RequestMapping("/")
	public String showWelcomePage(ModelMap map){
		
		return "welcome";
	}
	@RequestMapping("/pr")
	public String showcheck(ModelMap map){
		
				return "customerHomePage";
	}
	
	@RequestMapping("/adminlogin")
	public String showAdminLoginPage(ModelMap map,@ModelAttribute("admin") Admin admin){
		
		map.addAttribute("admin", admin);
		return "adminlogin";
	}
	@RequestMapping("/signUpPage")
	public String showSignUpPage(ModelMap map, @ModelAttribute("customer") Customers cus){
		
		
		map.addAttribute("customer", cus);
		return "signUpPage";
	}
	@RequestMapping("/signUp")
	public String signUpCostumer(ModelMap map,@Valid @ModelAttribute("customer") Customers cus, BindingResult error)
	{
		
		System.out.println("**inside signup in jsp controller");
		if(error.hasErrors())
		{
			System.out.println(error.toString());
			map.addAttribute("customer", cus);
			return "signUpPage";
		}
	
		System.out.println(cus.toString());
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("before posting to Central");
		Customers message = restTemplate.postForObject("http://localhost:9090/signUpCustomer",cus, Customers.class);
		System.out.println(message);
		if(message.getCustomerName().equals("Dummy"))
		{	
			map.addAttribute("errorSignUp", "Credentials are Wrong");
			map.addAttribute("custDetails", cus); 
			return "signUpPage";
		}
				
		else {
			map.addAttribute("custDetails", cus);
			return "customerHomePage";
		}
		 
		 
	}
	
	@RequestMapping("/merchantlogin")
	public String showMerchantLoginPage(ModelMap map){
		
		return "welcome";
	}
	
	@RequestMapping("/customerlogin")
	public String showConsumerLoginPage(ModelMap map){
		
		return "customerLogin";
	}
	@RequestMapping("/adminlogincheck")
	public String  adminLoginCheck(ModelMap map,@ModelAttribute("admin") Admin admin){
		
		RestTemplate restTemplate = new RestTemplate();
		
		Admin message = restTemplate.postForObject("http://localhost:9090/loginAdmin",admin, Admin.class);
		map.addAttribute("adminDetails", message);
		 //check
		 return "adminHomePage";
	}
	@RequestMapping("/customerlogincheck")
	public String  customerLoginCheck(ModelMap map,@ModelAttribute("customer") Customers customer){
		
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("**insiode jsp controller");
		Customers obj = restTemplate.postForObject("http://localhost:9090/loginCustomer",customer, Customers.class);
		System.out.println("after Central***** check JspHandler***"+obj.getCustomerName());
		ProductListDummy allProductList = restTemplate.getForObject("http://localhost:9090/productList", ProductListDummy.class);
		 
		List<Products> Electronics=allProductList.getSpecificProducts(ProductCategory.ElECTRONICS);
		List<Products> Books=allProductList.getSpecificProducts(ProductCategory.BOOKS);
		List<Products> Clothing=allProductList.getSpecificProducts(ProductCategory.FASHION);
		List<Products> Furniture=allProductList.getSpecificProducts(ProductCategory.HOME_and_FURNiSHINING);

		map.addAttribute("productListElectronics",Electronics);
		map.addAttribute("productListBooks", Books);
		map.addAttribute("productListClothing",Clothing );
		map.addAttribute("productListFurniture", Furniture);
		
		 map.addAttribute("custDetails", obj);
		 return "customerHomePage";
	}
	@RequestMapping("/homePage")
	public String showHomePage(ModelMap map, @ModelAttribute("customer") Customers cus){
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("inside homepage controller");
		ProductListDummy allProductList = restTemplate.getForObject("http://localhost:9090/productList", ProductListDummy.class);
				
		List<Products> Electronics=allProductList.getSpecificProducts(ProductCategory.ElECTRONICS);
		List<Products> Books=allProductList.getSpecificProducts(ProductCategory.BOOKS);
		List<Products> Clothing=allProductList.getSpecificProducts(ProductCategory.FASHION);
		List<Products> Furniture=allProductList.getSpecificProducts(ProductCategory.HOME_and_FURNiSHINING);

				map.addAttribute("productListElectronics",Electronics);
				map.addAttribute("productListBooks", Books);
				map.addAttribute("productListClothing",Clothing );
				map.addAttribute("productListFurniture", Furniture);
				
				map.addAttribute("customer", cus);
		return "customerHomePage";
	}
	
	
	@ModelAttribute("admin")
	Admin getCar() {
		Admin ac = new Admin();
		
		return ac;
	}
	@ModelAttribute("customer")
	Customers getCustomer() {
		Customers ac = new Customers();
		
		return ac;
	}
	
	
}